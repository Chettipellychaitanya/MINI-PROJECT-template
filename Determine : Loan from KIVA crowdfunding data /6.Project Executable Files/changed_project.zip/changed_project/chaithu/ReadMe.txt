step1 : conda create --name py35 python
step2 : conda activate py35
step3 : Enter into the project folder
step4 : pip install -r requirements.txt
step5 : python app.py